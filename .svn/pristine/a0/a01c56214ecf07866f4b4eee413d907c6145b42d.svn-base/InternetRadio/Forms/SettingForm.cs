﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Text;
using System.Windows.Forms;

namespace InternetRadio
{
    public partial class PropertyForm : Form
    {
        
        
        public PropertyForm()
        {
            InitializeComponent();
        }
        public EventHandler ColorForm {get;set;}
        

        private void bSetClose_Click(object sender, EventArgs e)
        {
  
            Hide();
        }

      

        private void PropertyForm_Load(object sender, EventArgs e)
        {

        }

        
    }
}
