﻿namespace MIr
{
    partial class VersionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbVersion = new System.Windows.Forms.ListBox();
            this.dtDate = new System.Windows.Forms.DateTimePicker();
            this.tbChanges = new System.Windows.Forms.TextBox();
            this.tbAddVer = new System.Windows.Forms.MaskedTextBox();
            this.dtAddDate = new System.Windows.Forms.DateTimePicker();
            this.tbAddChanges = new System.Windows.Forms.TextBox();
            this.bAddVersion = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lCurVer = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbVersion
            // 
            this.lbVersion.BackColor = System.Drawing.Color.Silver;
            this.lbVersion.FormattingEnabled = true;
            this.lbVersion.Items.AddRange(new object[] {
            "1.0.0.0"});
            this.lbVersion.Location = new System.Drawing.Point(12, 30);
            this.lbVersion.Name = "lbVersion";
            this.lbVersion.Size = new System.Drawing.Size(47, 108);
            this.lbVersion.TabIndex = 0;
            this.lbVersion.SelectedValueChanged += new System.EventHandler(this.LbVersionSelectedValueChanged);
            // 
            // dtDate
            // 
            this.dtDate.CalendarMonthBackground = System.Drawing.SystemColors.MenuHighlight;
            this.dtDate.Location = new System.Drawing.Point(65, 30);
            this.dtDate.Name = "dtDate";
            this.dtDate.Size = new System.Drawing.Size(200, 20);
            this.dtDate.TabIndex = 1;
            // 
            // tbChanges
            // 
            this.tbChanges.Location = new System.Drawing.Point(66, 57);
            this.tbChanges.Multiline = true;
            this.tbChanges.Name = "tbChanges";
            this.tbChanges.Size = new System.Drawing.Size(199, 81);
            this.tbChanges.TabIndex = 2;
            // 
            // tbAddVer
            // 
            this.tbAddVer.BackColor = System.Drawing.Color.Silver;
            this.tbAddVer.Location = new System.Drawing.Point(12, 153);
            this.tbAddVer.Mask = "9.9.9.9";
            this.tbAddVer.Name = "tbAddVer";
            this.tbAddVer.Size = new System.Drawing.Size(47, 20);
            this.tbAddVer.TabIndex = 4;
            this.tbAddVer.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.tbAddVer_MaskInputRejected);
            // 
            // dtAddDate
            // 
            this.dtAddDate.Location = new System.Drawing.Point(66, 153);
            this.dtAddDate.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
            this.dtAddDate.MinDate = new System.DateTime(2011, 1, 1, 0, 0, 0, 0);
            this.dtAddDate.Name = "dtAddDate";
            this.dtAddDate.Size = new System.Drawing.Size(200, 20);
            this.dtAddDate.TabIndex = 5;
            this.dtAddDate.Value = new System.DateTime(2012, 12, 2, 0, 0, 0, 0);
            // 
            // tbAddChanges
            // 
            this.tbAddChanges.Location = new System.Drawing.Point(12, 179);
            this.tbAddChanges.Multiline = true;
            this.tbAddChanges.Name = "tbAddChanges";
            this.tbAddChanges.Size = new System.Drawing.Size(252, 76);
            this.tbAddChanges.TabIndex = 6;
            // 
            // bAddVersion
            // 
            this.bAddVersion.Location = new System.Drawing.Point(13, 262);
            this.bAddVersion.Name = "bAddVersion";
            this.bAddVersion.Size = new System.Drawing.Size(75, 23);
            this.bAddVersion.TabIndex = 7;
            this.bAddVersion.Text = "Добавить";
            this.bAddVersion.UseVisualStyleBackColor = true;
            this.bAddVersion.Click += new System.EventHandler(this.bAddVersion_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Текущая версия:";
            // 
            // lCurVer
            // 
            this.lCurVer.AutoSize = true;
            this.lCurVer.Location = new System.Drawing.Point(109, 10);
            this.lCurVer.Name = "lCurVer";
            this.lCurVer.Size = new System.Drawing.Size(40, 13);
            this.lCurVer.TabIndex = 9;
            this.lCurVer.Text = "1.1.1.1";
            // 
            // VersionForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(273, 290);
            this.Controls.Add(this.lCurVer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bAddVersion);
            this.Controls.Add(this.tbAddChanges);
            this.Controls.Add(this.dtAddDate);
            this.Controls.Add(this.tbAddVer);
            this.Controls.Add(this.tbChanges);
            this.Controls.Add(this.dtDate);
            this.Controls.Add(this.lbVersion);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "VersionForm";
            this.Text = "Редактирование версий";
            this.Load += new System.EventHandler(this.VersionFormLoad);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.VersionForm_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.VersionForm_KeyPress);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.VersionForm_KeyUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lbVersion;
        private System.Windows.Forms.DateTimePicker dtDate;
        private System.Windows.Forms.TextBox tbChanges;
        private System.Windows.Forms.MaskedTextBox tbAddVer;
        private System.Windows.Forms.DateTimePicker dtAddDate;
        private System.Windows.Forms.TextBox tbAddChanges;
        private System.Windows.Forms.Button bAddVersion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lCurVer;
    }
}